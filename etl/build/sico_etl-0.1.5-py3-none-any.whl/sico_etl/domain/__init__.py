"""Domain contracts and validation."""
