"""PostgreSQL destination adapters."""
