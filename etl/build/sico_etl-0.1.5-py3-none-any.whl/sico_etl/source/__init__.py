"""Source adapters."""
